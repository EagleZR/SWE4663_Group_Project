package ksu.fall2017.swe4663.group1.projectmanagementsystem.gui;

import eaglezr.javafx.stages.PopupStage;
import eaglezr.support.errorsystem.ErrorPopupSystem;
import eaglezr.support.logs.LoggingTool;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.*;
import ksu.fall2017.swe4663.group1.projectmanagementsystem.Config;
import ksu.fall2017.swe4663.group1.projectmanagementsystem.Project;
import ksu.fall2017.swe4663.group1.projectmanagementsystem.ProjectPane;
import ksu.fall2017.swe4663.group1.projectmanagementsystem.gui.general.GeneralPane;
import ksu.fall2017.swe4663.group1.projectmanagementsystem.gui.hourlog.HourLogPane;
import ksu.fall2017.swe4663.group1.projectmanagementsystem.gui.requirements.RequirementsPane;
import ksu.fall2017.swe4663.group1.projectmanagementsystem.team.hourlog.SubmissionInterval;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

/**
 * Displays and modifies a {@link Project}. It is capable of creating new projects, saving the current project, and
 * loading a previous project.  <p>NOTE: This pane is meant to be set as the primary pane in the primary {@link Stage}.
 * Usage otherwise will result in awkward appearance.</p>
 *
 * @author Mark Zeagler
 * @version 1.0
 */
public class ProjectManagementPane extends BorderPane implements ProjectPane {

	private Stage primaryStage;
	private Project project;
	private Config config;
	private GeneralPane generalPane;
	private HourLogPane hourLogPane;
	private RequirementsPane requirementsPane;
	private Label statusLabel; // LATER Remove this?

	/**
	 * Constructs a {@link ProjectManagementPane}, which consists of a {@link GeneralPane}, a {@link HourLogPane}, and a
	 * {@link RequirementsPane}, as well as the {@link MenuBar} at the top and the status {@link Label} at the bottom.
	 * <p>NOTE: This pane is meant to be set as the primary pane in the {@link Scene} of the primary {@link Stage}.</p>
	 *
	 * @param stage   The {@link Stage} in which this pane is displayed.
	 * @param config  The {@link Config} which dictates the functionality and appearance of this pane.
	 * @param project The {@link Project} which will be displayed and modified by this pane.
	 */
	public ProjectManagementPane( Stage stage, Config config, Project project ) {
		LoggingTool.print( "Constructing new ProjectManagementPane." );
		this.project = project;
		this.config = config;
		this.primaryStage = stage;
		this.statusLabel = new Label( "Status: " );

		// Initialize primary panes
		BorderPane contentPane = new BorderPane();
		this.setTop( getNewMenuBar() );
		this.setCenter( contentPane );
		this.setBottom( this.statusLabel );

		////////////////////////////////////
		// Initialize tabs
		////////////////////////////////////
		LoggingTool.print( "ProjectManagementPane: Creating tabs in ProjectManagementPane." );
		Pane tabsPane = new Pane();
		contentPane.setTop( tabsPane );

		// General Pane
		LoggingTool.print( "ProjectManagementPane: Creating Button tab for GeneralPane in ProjectManagementPane." );
		Button generalPaneButton = new Button( "General" );
		generalPaneButton.setDefaultButton( true );
		generalPaneButton.prefWidthProperty().bind( tabsPane.widthProperty().divide( 3 ) );
		generalPaneButton.layoutXProperty().setValue( 0 );
		generalPaneButton.layoutYProperty().setValue( 0 );

		// Requirements
		LoggingTool.print( "ProjectManagementPane: Creating Button tab for RequirementPane in ProjectManagementPane." );
		Button requirements = new Button( "Requirements" );
		requirements.prefWidthProperty().bind( generalPaneButton.widthProperty() );
		requirements.layoutXProperty()
				.bind( generalPaneButton.layoutXProperty().add( generalPaneButton.widthProperty() ) );
		requirements.layoutYProperty().bind( generalPaneButton.layoutYProperty() );

		// Hours Expended
		LoggingTool.print( "ProjectManagementPane: Creating Button tab for HourLogPane in ProjectManagementPane." );
		Button hoursLog = new Button( "Hour Log" );
		hoursLog.prefWidthProperty().bind( generalPaneButton.widthProperty() );
		hoursLog.layoutXProperty().bind( requirements.layoutXProperty().add( requirements.widthProperty() ) );
		hoursLog.layoutYProperty().bind( generalPaneButton.layoutYProperty() );

		// Actions
		generalPaneButton.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Setting GeneralPane as content in ProjectManagementPane." );
			contentPane.setCenter( this.generalPane );
			generalPaneButton.setDefaultButton( true );
			requirements.setDefaultButton( false );
			hoursLog.setDefaultButton( false );

		} );
		requirements.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Setting RequirementPane as content in ProjectManagementPane." );
			contentPane.setCenter( this.requirementsPane );
			generalPaneButton.setDefaultButton( false );
			requirements.setDefaultButton( true );
			hoursLog.setDefaultButton( false );
		} );
		hoursLog.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Setting HourLogPane as content in ProjectManagementPane." );
			contentPane.setCenter( this.hourLogPane );
			generalPaneButton.setDefaultButton( false );
			requirements.setDefaultButton( false );
			hoursLog.setDefaultButton( true );
		} );
		tabsPane.getChildren().addAll( generalPaneButton, requirements, hoursLog );

		////////////////////////////////////
		// Initialize content panes
		////////////////////////////////////
		LoggingTool.print( "ProjectManagementPane: Creating GeneralPane in ProjectManagementPane." );
		this.generalPane = new GeneralPane( project, stage, config );
		this.generalPane.prefWidthProperty().bind( contentPane.widthProperty() );
		this.generalPane.prefHeightProperty()
				.bind( contentPane.heightProperty().subtract( tabsPane.heightProperty() ) );
		LoggingTool.print( "ProjectManagementPane: Creating RequirementPane in ProjectManagementPane." );
		this.requirementsPane = new RequirementsPane( project, stage, config );
		this.requirementsPane.prefWidthProperty().bind( contentPane.widthProperty() );
		this.requirementsPane.prefHeightProperty()
				.bind( contentPane.heightProperty().subtract( tabsPane.heightProperty() ) );
		LoggingTool.print( "ProjectManagementPane: Creating HourLogPane in ProjectManagementPane." );
		this.hourLogPane = new HourLogPane( project, stage, config );
		this.hourLogPane.prefWidthProperty().bind( contentPane.widthProperty() );
		this.hourLogPane.prefHeightProperty()
				.bind( contentPane.heightProperty().subtract( tabsPane.heightProperty() ) );
		LoggingTool.print( "ProjectManagementPane: Setting GeneralPane as content in ProjectManagementPane." );
		contentPane.setCenter( this.generalPane );
		this.generalPane.prefWidthProperty().bind( contentPane.widthProperty() );
	}

	/**
	 * Builds and returns the {@link MenuBar} for this pane.
	 *
	 * @return The new {@link MenuBar} for thi pane.
	 */
	private MenuBar getNewMenuBar() {
		LoggingTool.print( "ProjectManagementPane: Creating MenuBar." );
		MenuBar menuBar = new MenuBar();

		// File
		Menu file = new Menu( "File" );
		MenuItem newProject = new MenuItem( "New" );
		newProject.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: New Project Created." );
			this.project = new Project();
			this.config.previousSave = new File( this.config.savesDirectory.getPath() + "\\newProject.save" );
			loadNewProject( this.project );
		} );
		MenuItem save = new MenuItem( "Save" );
		MenuItem saveAs = new MenuItem( "Save As" );
		save.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Save button pressed." );
			if ( !this.config.previousSave.exists() ) {
				saveAs.fire();
			} else {
				LoggingTool.print( "ProjectManagementPane: Saving to " + this.config.previousSave.getAbsolutePath()
						+ "." );
				try {
					Project.save( this.project, this.config.previousSave );
				} catch ( IOException e1 ) {
					ErrorPopupSystem.displayMessage( "The file could not be saved." );
				}
			}
		} );
		saveAs.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Save As button pressed." );
			FileChooser chooser = new FileChooser();
			chooser.setTitle( "Please select where to save the file." );
			chooser.setInitialDirectory( this.config.savesDirectory );
			if ( !this.config.savesDirectory.exists() ) {
				if ( this.config.savesDirectory.mkdirs() ) {
					LoggingTool.print( "ProjectManagementPane: The saves directory did not exist, and was created." );
				} else {
					LoggingTool
							.print( "ProjectManagementPane: The saves directory did not exist, and could not be created." );
					ErrorPopupSystem.displayMessage( "There was an error opening the saves directory." );
					return;
				}
			}
			chooser.getExtensionFilters().add( new FileChooser.ExtensionFilter( "Project Save File",
					"*." + this.config.saveFileExtension ) );
			chooser.setInitialFileName(
					"save" ); // LATER Add a number afterwards and increase if a file already exists with that name?

			Stage fileChooserStage = new Stage();
			fileChooserStage.initModality( Modality.APPLICATION_MODAL );
			fileChooserStage.initOwner( this.primaryStage );
			fileChooserStage.initStyle( StageStyle.UTILITY );
			fileChooserStage.resizableProperty().setValue( false );

			File chosenFile = chooser.showSaveDialog( fileChooserStage );

			if ( chosenFile != null ) {
				if ( chosenFile.getName().length() < 5 || !chosenFile.getName()
						.substring( chosenFile.getName().length() - 6 )
						.equals( "." + this.config.saveFileExtension ) ) {
					chosenFile = new File( chosenFile.getPath() + "." + this.config.saveFileExtension );
				}
				this.config.previousSave = chosenFile;

				try {
					Project.save( this.project, this.config.previousSave );
				} catch ( IOException e1 ) {
					ErrorPopupSystem.displayMessage( "Unable to save the file." );
					LoggingTool.print( "ProjectManagementPane: Unable to save the file." );
					e1.printStackTrace();
				}
			}

			fileChooserStage.close();
		} );
		MenuItem load = new MenuItem( "Load" );
		load.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Load button pressed." );
			FileChooser chooser = new FileChooser();
			chooser.setTitle( "Please select which file to load." );
			if ( !this.config.savesDirectory.exists() ) {
				LoggingTool.print( "ProjectManagementPane: The directory " + this.config.savesDirectory.getName()
						+ " does not exist." );
				if ( this.config.savesDirectory.mkdir() ) {
					LoggingTool.print( "ProjectManagementPane: The directory " + this.config.savesDirectory.getName()
							+ " was successfully created." );
				} else {
					LoggingTool.print( "ProjectManagementPane: The directory " + this.config.savesDirectory.getName()
							+ " could not be created." );
				}
			}
			chooser.setInitialDirectory( this.config.savesDirectory );
			chooser.setSelectedExtensionFilter( new FileChooser.ExtensionFilter( "Project Save File", ".save" ) );
			if ( this.config.previousSave != null && this.config.previousSave.exists() ) {
				chooser.setInitialFileName( this.config.previousSave.getName() );
			}

			Stage fileChooserStage = new Stage();
			fileChooserStage.initModality( Modality.APPLICATION_MODAL );
			fileChooserStage.initOwner( this.primaryStage );
			fileChooserStage.initStyle( StageStyle.UTILITY );
			fileChooserStage.resizableProperty().setValue( false );

			File chosenFile = chooser.showOpenDialog( fileChooserStage );

			if ( chosenFile != null ) {
				try {
					// Load into new project to ensure successful load before discarding the old one
					Project project = Project.load( chosenFile );
					this.project = project;
					loadNewProject( this.project );
					this.config.previousSave = chosenFile;
				} catch ( IOException e1 ) {
					ErrorPopupSystem.displayMessage( "Unable to load the file." );
					LoggingTool.print( "ProjectManagementPane: Unable to load the file." );
					LoggingTool.print( e1.getMessage() );
					e1.printStackTrace();
				} catch ( ClassNotFoundException e1 ) {
					ErrorPopupSystem.displayMessage( "That file does not exist" );
					LoggingTool.print( "ProjectManagementPane: The specified file does not exist." );
					LoggingTool.print( e1.getMessage() );
					e1.printStackTrace();
				}
			}

			fileChooserStage.close();
		} );
		MenuItem exit = new MenuItem( "Exit" );
		exit.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Exit button pressed." );
			Platform.exit();
		} );
		file.getItems().addAll( newProject, save, saveAs, load, exit );

		// Options
		Menu options = new Menu( "Options" );
		MenuItem settings = new MenuItem( "Settings" );
		settings.setOnAction( e -> {
			LoggingTool.print( "ProjectManagementPane: Settings button pressed." );
			Pane settingsPane = new Pane();

			// Saves Directory
			Label savesLabel = new Label( "Saves Directory:" );
			savesLabel.layoutXProperty().setValue( this.config.buffer );
			savesLabel.layoutYProperty().setValue( this.config.buffer );
			settingsPane.getChildren().add( savesLabel );

			TextField savesField = new TextField( this.config.savesDirectory.getAbsolutePath() );
			File savesDirectory = this.config.savesDirectory;

			Button savesDirectoryChooser = new Button( "..." );
			savesDirectoryChooser.layoutXProperty()
					.bind( settingsPane.widthProperty().subtract( savesDirectoryChooser.widthProperty() )
							.subtract( this.config.buffer ) );
			savesDirectoryChooser.layoutYProperty()
					.bind( savesLabel.layoutYProperty().add( savesLabel.heightProperty() )
							.add( this.config.buffer / 2 ) );
			savesDirectoryChooser.setOnAction( ae -> {
				DirectoryChooser directoryChooser = new DirectoryChooser();
				if ( this.config.savesDirectory.exists() ) {
					directoryChooser.setInitialDirectory( this.config.savesDirectory );
				} else {
					if ( this.config.savesDirectory.mkdir() ) {
						LoggingTool
								.print( "ProjectManagementPane: The directory " + this.config.savesDirectory.getName()
										+ " was successfully created." );
					} else {
						LoggingTool
								.print( "ProjectManagementPane: The directory " + this.config.savesDirectory.getName()
										+ " could not be created." );
					}
				}
				directoryChooser.setTitle( "Choose a default Saves directory" );

				Stage fileChooserStage = new Stage();
				fileChooserStage.initModality( Modality.APPLICATION_MODAL );
				fileChooserStage.initOwner( this.primaryStage );
				fileChooserStage.initStyle( StageStyle.UTILITY );
				fileChooserStage.resizableProperty().setValue( false );

				this.config.savesDirectory = directoryChooser.showDialog( fileChooserStage );
				savesField.setText( this.config.savesDirectory.getAbsolutePath() );
			} );
			settingsPane.getChildren().add( savesDirectoryChooser );

			savesField.layoutXProperty().bind( savesLabel.layoutXProperty() );
			savesField.layoutYProperty().bind( savesDirectoryChooser.layoutYProperty() );
			savesField.prefWidthProperty()
					.bind( savesDirectoryChooser.layoutXProperty().subtract( savesField.layoutXProperty() )
							.subtract( this.config.buffer / 4 ) );
			savesField.setEditable( false );
			settingsPane.getChildren().add( savesField );

			// Hour Log Interval
			Label hourLogLabel = new Label( "Hours Submission Interval" );
			hourLogLabel.layoutXProperty().bind( savesField.layoutXProperty() );
			hourLogLabel.layoutYProperty()
					.bind( savesField.layoutYProperty().add( savesDirectoryChooser.heightProperty() )
							.add( this.config.buffer ) );
			settingsPane.getChildren().add( hourLogLabel );

			ComboBox<SubmissionInterval> submissionIntervalComboBox = new ComboBox<>(
					FXCollections.observableArrayList( SubmissionInterval.values() ) );
			submissionIntervalComboBox.layoutXProperty().bind( hourLogLabel.layoutXProperty() );
			submissionIntervalComboBox.layoutYProperty()
					.bind( hourLogLabel.layoutYProperty().add( hourLogLabel.heightProperty() )
							.add( this.config.buffer / 2 ) );
			if ( this.project.getTeam().getProjectHourLog().getSubmissionInterval() != null ) {
				submissionIntervalComboBox
						.setValue( this.project.getTeam().getProjectHourLog().getSubmissionInterval() );
				submissionIntervalComboBox.setEditable( false );
			}
			settingsPane.getChildren().add( submissionIntervalComboBox );

			Scene scene = new Scene( settingsPane, 300, 200 );
			PopupStage popupStage = new PopupStage( scene, this.primaryStage );
			popupStage.setTitle( "Settings" );

			// Apply
			Button apply = new Button( "Apply" );
			apply.layoutXProperty().setValue( this.config.buffer / 2 );
			apply.layoutYProperty().bind( settingsPane.heightProperty().subtract( apply.heightProperty() )
					.subtract( this.config.buffer / 2 ) );
			apply.setOnAction( ae -> {
				if ( this.project.getTeam().getProjectHourLog().getSubmissionInterval() == null ) {
					this.project.getTeam().getProjectHourLog()
							.setSubmissionInterval( submissionIntervalComboBox.getValue() );
					popupStage.close();
				}
			} );
			settingsPane.getChildren().add( apply );

			// Cancel
			Button cancel = new Button( "Cancel" );
			cancel.layoutXProperty().bind( settingsPane.widthProperty().subtract( cancel.widthProperty() )
					.subtract( this.config.buffer / 2 ) );
			cancel.layoutYProperty().bind( settingsPane.heightProperty().subtract( cancel.heightProperty() )
					.subtract( this.config.buffer / 2 ) );
			cancel.setOnAction( ae -> {
				this.config.savesDirectory = savesDirectory;
				popupStage.close();
			} );
			settingsPane.getChildren().add( cancel );

			popupStage.show();
		} );
		options.getItems().addAll( settings );

		// Help
		Menu help = new Menu( "Help" );
		MenuItem helpItem = new MenuItem( "Help" );
		helpItem.setOnAction( e -> {
			try {
				Desktop.getDesktop()
						.browse( new URI( "http://markzeagler.com/docs/projectmanagementsystem/index.html" ) );
				LoggingTool.print( "ProjectManagementPane: Showing help page." );
			} catch ( URISyntaxException | IOException e1 ) {
				ErrorPopupSystem.displayMessage( "Unable to open URL" );
				LoggingTool.print( e1.getMessage() );
			}
		} );

		// About
		MenuItem about = new MenuItem( "About" );
		about.setOnAction( e -> {
			AboutPane aboutPane = new AboutPane( this.config );
			Scene scene = new Scene( aboutPane, 500, 400 );
			PopupStage popupStage = new PopupStage( scene, this.primaryStage );
			popupStage.setTitle( "About" );
			popupStage.show();
		} );
		help.getItems().addAll( helpItem, about );

		menuBar.getMenus().addAll( file, options, help );

		return menuBar;
	}

	/**
	 * Loads a new {@link Project} into this pane and its sub-panes.
	 *
	 * @param project The new {@link Project} to display.
	 */
	@Override public void loadNewProject( Project project ) {
		this.generalPane.loadNewProject( project );
		this.hourLogPane.loadNewProject( project );
		this.requirementsPane.loadNewProject( project );
		LoggingTool.print( "ProjectManagementPane: Loaded new project." );
	}
}
