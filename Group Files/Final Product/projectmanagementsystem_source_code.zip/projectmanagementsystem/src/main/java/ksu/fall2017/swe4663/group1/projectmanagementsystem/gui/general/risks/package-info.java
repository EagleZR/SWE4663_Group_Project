/**
 * Package of the files and classes used to display the {@link ksu.fall2017.swe4663.group1.projectmanagementsystem.gui.general.risks.RisksPane}
 * and its supporting panes within the {@link ksu.fall2017.swe4663.group1.projectmanagementsystem}.
 *
 * @author Mark Zeagler
 * @version 1.0
 */

package ksu.fall2017.swe4663.group1.projectmanagementsystem.gui.general.risks;
