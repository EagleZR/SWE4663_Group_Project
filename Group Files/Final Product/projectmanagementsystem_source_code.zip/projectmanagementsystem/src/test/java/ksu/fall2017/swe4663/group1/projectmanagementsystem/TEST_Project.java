package ksu.fall2017.swe4663.group1.projectmanagementsystem;

import org.junit.Test;

import static org.junit.Assert.*;

public class TEST_Project {
	@Test public void save() throws Exception {
	}

	@Test public void save1() throws Exception {
	}

	@Test public void load() throws Exception {
	}

	@Test public void load1() throws Exception {
	}

	@Test public void getTeam() throws Exception {
	}

	@Test public void getRisks() throws Exception {
	}

	@Test public void getRequirements() throws Exception {
	}

	@Test public void equals() throws Exception {
	}

}
