package ksu.fall2017.swe4663.group1.projectmanagementsystem.gui.general.risks;

import javafx.application.Application;
import javafx.stage.Stage;

public class TEST_RisksPane extends Application {
	@Override public void start( Stage primaryStage ) throws Exception {

	}
}
